import React from 'react';


function Contents({ children }){
    return <main id="main">{children}</main>
}
export default Contents;